package com.riki.customer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerRestclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerRestclientApplication.class, args);
	}

}
